package com.BookshopSystem.entities;

public enum EditionType {
    NORMAL, PROMO, GOLD
}
