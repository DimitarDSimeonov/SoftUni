package com.BookshopSystem.entities;

public enum AgeRestriction {
    MINOR, TEEN, ADULT
}
